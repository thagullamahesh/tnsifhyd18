package com.coreconcepts.finall;

public class FinalMethod1 {
	
	final void run() {
		System.out.println("Running");
	}

}
