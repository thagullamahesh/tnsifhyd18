package com.methodoverriding;

public class Parent {
	
	//Instance method
	public void show() {
		System.out.println("Parents show() is called");
	}
	
	//Static method
	public static void print() {
		System.out.println("Parent static print() is called");
	}
}
