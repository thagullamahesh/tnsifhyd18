package com.oop2.inheritence;

public class HierarchialInheritenceD extends HierarchialInheritenceA{
	
	public void output() {
		System.out.println("I am a method from class D");
	}

}
