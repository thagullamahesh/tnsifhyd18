package com.oop2.inheritence;

public class HierarchialInheritenceB extends HierarchialInheritenceA {
	
	public void print() {
		System.out.println("I am a method from class B");
	}

}
