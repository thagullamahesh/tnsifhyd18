package com.oop2.inheritence;

public class MultilevelPerson1 {
	
	String getName() {
		return "progrramerBay";
	}

}
