package com.oop2.inheritence;

public class Dog extends Animal{
	
	public void display() {
		System.out.println("My name is " + name);
	}

}
